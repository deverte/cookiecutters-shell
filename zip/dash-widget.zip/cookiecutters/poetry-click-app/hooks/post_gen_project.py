import os

os.system('deactivate & poetry install')