"""Initializes dash controllers."""

import {{cookiecutter.app_name}}.dash_app.widgets.controller
## Import your controllers here.
# import {{cookiecutter.app_name}}.dash_app.widgets.{children}.{child}.controller