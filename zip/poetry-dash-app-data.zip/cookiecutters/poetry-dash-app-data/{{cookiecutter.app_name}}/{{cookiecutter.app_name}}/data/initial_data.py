"""Initial data for `Dash` app."""

from box import Box

## Set your initial data here.
initial_data = Box(
    {
        'extra_block_div': {
            'is_hidden': True
        }
    }
)